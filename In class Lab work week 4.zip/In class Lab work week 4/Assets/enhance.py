# enhance.py
from PIL import Image, ImageEnhance
# import an image
image = Image.open('1_Limniu 2021_1_2021_06_02-13-08-37-981.png')
# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)
# apply the enhancer
enhanced_image = sharpness_enhancer.enhance(1.5)
# show
image.show()
enhanced_image.show()